# CropWise Security & Deployment Notes

## 1. Authentication

CropWise uses authenticated access for protected workflows.

The backend uses:

- JWT authentication
- password hashing
- role-based access control

## 2. Admin Access

Admin-only endpoints are protected by an admin guard.

Admin credentials belong in environment configuration, not source code or documentation.

The README should never contain real deployment credentials.

## 3. Secrets

Sensitive values such as:

- API keys
- JWT secrets
- admin credentials

must remain server-side.

Use `.env` locally and deployment environment settings in hosted environments.

Never commit secrets.

## 4. Privacy

Public farmer/buyer representations should avoid exposing unnecessary private contact information.

Authenticated profile endpoints may expose information required for the user's own workflows.

## 5. Marketplace Validation

Important business rules are validated server-side rather than relying only on frontend checks.

Examples include:

- positive price/quantity
- offer quantity limits
- minimum acceptable price
- listing state
- offer state transitions
- owner authorization for protected matching/transaction actions

## 6. Database / Deployment

SQLite is convenient for prototype development but requires care on hosted platforms.

A deployment using ephemeral local storage can lose data after restart/redeploy.

For a deployment with real user data:

1. use persistent storage or a production database
2. back up existing data
3. verify `DATABASE_URL`
4. verify migration/startup behavior

## 7. Payments

The current system does not integrate a live financial gateway.

Payment/transaction states are application records, not proof of money movement.

## 8. Production Boundary

CropWise is currently a prototype.

Before production use, it would require a broader security review covering:

- secret management
- dependency patching
- database hardening
- rate limiting
- audit logging
- CORS/security headers
- session/token policy
- infrastructure hardening
- monitoring
- backup/recovery
