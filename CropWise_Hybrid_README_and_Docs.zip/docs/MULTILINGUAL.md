# CropWise Multilingual Architecture

## 1. Design Rule

Language is a presentation/NLU concern, not a separate business-logic implementation.

```text
Input language
     ↓
Language-neutral parsing
     ↓
Canonical entities
     ↓
Common business logic
     ↓
Localized response
```

## 2. Intent / Entity Pipeline

The assistant can extract business entities such as:

- crop
- quantity
- location

and identify supported intent categories.

Conversation context can carry values such as:

```text
known_crop
known_quantity_kg
known_location
```

## 3. Clarification

A core trust rule is:

> Do not silently invent a crop or location.

If required information is missing or ambiguous, the assistant should request clarification instead of substituting an arbitrary default.

## 4. Translation Boundary

The frontend and backend maintain localized resources while business services operate on canonical entities.

Example:

```text
Stored entity:
Soybean

Localized display:
सोयाबीन
সয়াবিন
சோயாபீன்
...
```

This avoids duplicating market/recommendation logic for every language.

## 5. Voice

Speech features use browser-native Web Speech APIs.

Voice support is therefore:

- browser-dependent
- operating-system-dependent
- locale-dependent

The application should not claim universal STT/TTS support merely because the UI contains a microphone or speaker control.

## 6. Marketplace Text

Freeform listing/offer text is not automatically machine-translated without a configured translation provider.

The safe behavior is:

```text
Original text
+
Source language
```

rather than pretending a translation exists.

## 7. Scope

The repository contains multiple Indian-language resources plus fallback languages.

However, full UI translation coverage is still being expanded across all major page surfaces. Text/assistant capability should not automatically be interpreted as complete translation of every UI string.

## 8. Adding a Language

A new fully supported language generally requires:

1. language metadata
2. crop aliases
3. intent keywords
4. response templates
5. frontend translation resources

Business routers and recommendation logic should remain unchanged.
