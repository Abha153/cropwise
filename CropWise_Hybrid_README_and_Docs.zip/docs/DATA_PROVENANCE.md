# CropWise Data Provenance

## 1. Why Provenance Matters

CropWise makes selling decisions from values that may come from different sources.

A value should therefore communicate whether it is:

- live
- demo
- estimated
- unavailable

The project intentionally avoids presenting synthetic data as if it were observed market data.

## 2. Data States

| State | Meaning |
|---|---|
| LIVE | Successfully retrieved from an external source |
| DEMO | Deterministic demonstration/fallback dataset |
| ESTIMATED | Calculated from an explicit model or heuristic |
| UNAVAILABLE | No trustworthy value is available |

## 3. Market Data

The live-market path integrates with government open-data resources through backend services.

The architecture includes:

```text
Local market/location
        ↓
Mandi discovery/mapping
        ↓
Live market resource(s)
        ↓
Record validation
        ↓
Persist verified observation
```

A local town name is not automatically assumed to equal a government's exact mandi-name string. The mandi-directory layer exists to map local names to actual data-source records.

## 4. Critical Current Limitation

The current checkpoint has a known live-market validation regression:

- market filtering is not yet strict enough in one live-data path
- the first returned record is not sufficiently cross-checked against the requested market/commodity

Until this is fixed, the live-market result path should be treated as requiring further validation.

## 5. Historical Prices and Forecasts

Synthetic historical prices may be useful for demonstrating the algorithm, but they should not be silently mixed with real historical observations.

Preferred policy:

```text
Real observations
    ↓
Persist as real data
    ↓
Historical chart / forecast
```

Demo data:

```text
Explicit include_demo mode
    ↓
Clearly tagged demonstration series
```

The forecast should not claim to be trained ML merely because it uses historical observations.

## 6. Weather

Weather should surface one of:

- LIVE
- DEMO
- UNAVAILABLE

The DEMO state is not equivalent to current real-world weather.

## 7. Transport

Transport results are calculated outputs.

They should be described as **estimates/models**, not confirmed carrier quotations.

## 8. Quality

The current quality-analysis feature is a heuristic/demo boundary.

It is not evidence of a trained crop-quality computer-vision model.

## 9. FarmPool

Partner identities shown in demo FarmPool workflows can be simulated.

Until explicit labeling is wired into every relevant response/UI surface, these records must not be represented as verified real farmers.

## 10. General Rule

> If CropWise does not know that a value is real, it should not present the value as real.
