# CropWise Architecture

## 1. System Overview

CropWise is organized as a React/Vite frontend communicating with a modular FastAPI backend.

```text
Frontend
   │
   │ REST / JSON
   ▼
FastAPI
   │
   ├── Authentication / RBAC
   ├── Market Intelligence
   ├── Forecasting
   ├── Recommendation
   ├── Buyer Matching
   ├── Transport
   ├── Profit Analysis
   ├── Assistant / NLU
   ├── Listings / Offers
   ├── Transactions / Payments
   ├── Group Selling / FarmPool
   ├── Weather
   ├── Storage / Quality
   └── Admin / Notifications
   │
   ▼
SQLAlchemy
   │
   ▼
SQLite
```

## 2. Decision-Support Flow

```text
Farmer
  ↓
Crop / Quantity
  ↓
Location
  ↓
Market observations
  ↓
Transport model
  ↓
Selling-cost model
  ↓
Expected net realization
  ↓
Recommendation / comparison
  ↓
Buyer discovery
  ↓
Offer / transaction
```

## 3. Assistant Flow

```text
User text
  ↓
Language/entity parsing
  ↓
Intent classification
  ↓
Entity/context validation
  ↓
Intent-specific business logic
  ↓
Localized response
```

The assistant is not intended to be a general-purpose LLM.

## 4. Forecasting Flow

```text
Historical observations
  ↓
Trend
  +
Volatility
  ↓
Forecast
  ↓
Walk-forward backtest
  ↓
MAE / RMSE / MAPE
```

The present forecast is a transparent statistical baseline.

## 5. Location Flow

The reusable location layer represents:

```text
IDLE
DETECTING
SUCCESS
PERMISSION_DENIED
TIMEOUT
UNAVAILABLE
UNSUPPORTED
```

Location-aware pages should not treat a failed GPS request as a successful location lookup.

## 6. Design Principles

### Explainability
Recommendations expose the important factors behind the result.

### Separation of concerns
Language is separated from business logic.

### Provenance
Data source/state is preserved instead of being silently inferred.

### Replaceable service boundaries
Forecasting, translation and quality-analysis services have boundaries that can later accept stronger implementations without redesigning the entire UI/API.

## 7. Architecture Caveat

The repository is an evolving prototype. Do not hard-code README documentation to fixed router/page counts. The current backend and frontend are more modular than older README checkpoints reported, and module counts may change as development continues.
