# 🌾 CropWise

### Smart Markets. Better Prices. Stronger Farmers.

**CropWise** is a market-linkage and price-discovery platform that helps farmers compare selling options using **market prices, location, transport costs, expected net realization, and buyer discovery** in one workflow.

> ## Price ≠ Best Selling Option
>
> The market with the highest displayed price is not automatically the market that gives the farmer the best outcome after transport and other relevant costs.

---

## 🌐 Demo

**Live frontend:** https://cropwise-alpha.vercel.app/

**Repository:** https://github.com/Abha153/cropwise

CropWise is a **working prototype** focused on the core market-intelligence → decision-support → buyer-discovery → selling workflow.

---

## 🎯 The Problem

Farmers often have to make several connected decisions before selling:

- Where should I sell?
- Is the highest quoted price actually the best option after transport?
- Should I sell now or consider waiting?
- Which buyer is suitable?
- What will my expected realization look like after costs?

CropWise connects those decisions instead of treating them as separate features.

---

## 💡 Core Decision Flow

```text
Farmer
  ↓
Crop + Quantity
  ↓
Location
  ↓
Market Intelligence
  ↓
Price Comparison
  ↓
Transport Cost
  ↓
Expected Net Realization
  ↓
Buyer Discovery
  ↓
Selling Journey
  ↓
Transaction
```

A simplified model is:

```text
Expected Net Realization
=
Expected Sale Value
− Transport Cost
− Relevant Selling Costs
```

This is **decision support**, not a guarantee of profit or sale outcome.

---

## ✨ What CropWise Provides

| Area | Current capability | Status |
|---|---|---|
| 📊 Market Intelligence | Market comparison, price records and location-aware discovery | ✅ |
| 💰 Best Selling Option | Net-realization comparison with explainable factors | ✅ |
| 🚚 Transport Intelligence | Vehicle/fuel/driver/overhead/toll/minimum-trip model | ✅ |
| 🤖 AgriAdvisor | Explainable rule-based decision support | ✅ |
| 📈 Price Forecast | Trend + volatility statistical baseline with walk-forward backtesting | ✅ |
| 🤝 Buyer Matching | Explainable 0–100 buyer score | ✅ |
| 🌾 FarmPool | Shared-transport workflow | ⚠️ Prototype / simulated partner data |
| 🧮 Profit Calculator | Side-by-side selling scenarios | ✅ |
| 🤝 Group Selling | Farmer pooling and membership tracking | ✅ |
| 🌦 Weather | LIVE / DEMO / UNAVAILABLE states | ✅ |
| 📍 GPS / Location | Browser geolocation and explicit failure states | ✅ |
| 🌐 Multilingual Assistant | Language-neutral intent/entity pipeline and localized responses | ✅ |
| 📷 Quality Assessment | Heuristic/demo grading boundary for future CV model | ⚠️ |
| 💳 Payments | Transaction/payment state tracking | ⚠️ No live gateway |
| 🛡️ Admin | RBAC-protected admin workflows | ✅ |

**Status means implementation/verification at the current checkpoint, not production readiness.**

---

## 🤖 Decision Support, Not “AI” by Default

CropWise intentionally separates current statistical/rule-based functionality from future trained models.

### Current

- rule-based recommendations
- explainable buyer matching
- statistical price forecasting
- keyword/entity multilingual intent detection
- heuristic quality assessment
- transport optimization
- location-aware decision support

### Future

- learned market ranking
- stronger time-series forecasting
- trained computer-vision quality assessment
- richer multilingual semantic NLU
- larger-scale recommendation models

The project does **not** describe a statistical baseline or heuristic as a trained ML model.

---

## 📈 Price Forecasting

The current forecasting service uses:

```text
Historical Prices
      ↓
Trend Estimation
      ↓
Volatility
      ↓
Forecast
      ↓
Walk-Forward Backtest
```

The implementation includes least-squares trend estimation and walk-forward MAE/RMSE/MAPE evaluation where sufficient real observations exist.

The current model is **not trained ML** and should be presented as a transparent statistical baseline.

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) and [docs/DATA_PROVENANCE.md](docs/DATA_PROVENANCE.md).

---

## 🌦 Data Provenance

CropWise distinguishes:

- 🟢 **LIVE** — externally retrieved data
- 🟡 **DEMO** — deterministic demonstration data
- 🔵 **ESTIMATED** — calculated from an explicit model/heuristic
- 🔴 **UNAVAILABLE** — no trustworthy value available

The application is designed not to silently turn demo or unavailable data into “real” observations.

See [docs/DATA_PROVENANCE.md](docs/DATA_PROVENANCE.md).

---

## 🌐 Multilingual Architecture

The language layer is separated from the business logic:

```text
Typed / Spoken Input
        ↓
Language-Neutral NLU
        ↓
Intent + Entities
        ↓
CropWise Business Logic
        ↓
Localized Response
```

This keeps market comparison, recommendations and validation independent of the selected language.

The repository contains multiple Indian-language resources plus fallback languages. Browser STT/TTS capability is device-dependent and is therefore not presented as universally guaranteed.

Detailed capability and architecture notes:
[docs/MULTILINGUAL.md](docs/MULTILINGUAL.md)

---

## 🏗️ Architecture

```text
┌─────────────────────────────────────────────────────┐
│                  React / Vite UI                    │
│ Dashboards • Market • Forecast • Buyer • Selling   │
└──────────────────────┬──────────────────────────────┘
                       │ REST / JSON
                       ▼
┌─────────────────────────────────────────────────────┐
│                    FastAPI                          │
│ Auth • Market • Forecast • Matching • Logistics    │
│ Profit • Assistant • Listings • Offers • Buyers   │
│ Group Selling • Weather • Admin • Transactions    │
└──────────────────────┬──────────────────────────────┘
                       │
          ┌────────────┼────────────┐
          ▼            ▼            ▼
    Business       Data/External   Access Control
    Services        Services       JWT / RBAC
    ─────────       ───────────    ─────────
    Recommendation Market Data
    Forecasting    Weather
    Matching       Location
    Transport      Persistence
    Profit
    Quality
          │
          ▼
┌─────────────────────────────────────────────────────┐
│                 SQLAlchemy                         │
└──────────────────────┬──────────────────────────────┘
                       ▼
                    SQLite
```

The backend is modular; router/service counts may evolve as the prototype changes.

---

## 🛠️ Tech Stack

### Frontend
- React 18
- Vite
- Tailwind CSS
- Recharts
- React Router
- Browser Web Speech API
- Custom i18n

### Backend
- Python
- FastAPI
- SQLAlchemy
- Pydantic
- JWT authentication
- bcrypt

### Data / platform integrations
- Government/open-data market integration path
- Open-Meteo weather integration
- Browser Geolocation API
- Browser Web Speech API

---

## 🔐 Security & Access Control

CropWise includes:

- JWT authentication
- password hashing
- role-based access control
- admin-only dependencies
- authenticated farmer/buyer workflows
- server-side marketplace validation
- protected transaction operations

The prototype is **not** a production-hardened government or financial platform.

See [docs/SECURITY.md](docs/SECURITY.md).

---

## 🧪 Current Validation Status

The latest audited checkpoint reported:

```text
65 passed
5 errors
7 warnings
```

The known errors were associated with a **passlib / bcrypt compatibility issue** in the login-tracking test path.

The project also has two high-priority known issues that should remain visible until fixed:

1. stricter validation of fetched live market records
2. explicit labeling of simulated FarmPool partner data

See [docs/IMPLEMENTATION_STATUS.md](docs/IMPLEMENTATION_STATUS.md).

---

## 🚀 Run Locally

### Prerequisites

- Python 3.10+
- Node.js 18+
- npm

### Backend

```bash
git clone https://github.com/Abha153/cropwise.git
cd cropwise/backend

python -m venv venv
```

Windows:

```powershell
venv\Scripts\activate
```

Linux/macOS:

```bash
source venv/bin/activate
```

```bash
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --port 8000
```

API docs:

```text
http://localhost:8000/docs
```

### Frontend

In another terminal:

```bash
cd frontend
npm install
npm run dev
```

Usually:

```text
http://localhost:5173
```

---

## 👥 Demo Roles

The repository contains seeded demo farmer and buyer workflows for local development.

Use the in-app **demo account** options on the login page rather than treating seeded credentials as production credentials.

For deployment/admin configuration, see [docs/SECURITY.md](docs/SECURITY.md).

---

## 🎬 Suggested Demo Flow

```text
Farmer Login
    ↓
Market Intelligence
    ↓
Compare Price + Transport
    ↓
Best Selling Option
    ↓
Price Forecast
    ↓
Buyer Matching
    ↓
FarmPool / Group Selling
    ↓
Offer
    ↓
Transaction
    ↓
Selling Journey
```

Then demonstrate:

```text
Multilingual Assistant
        ↓
Intent
        ↓
Crop / Quantity / Location
        ↓
Clarification if needed
        ↓
Decision-support response
```

---

## ⚠️ Current Limitations

CropWise is a prototype.

- **Live market data:** the integration path exists, but the current checkpoint needs stricter record-level validation before accepting every fetched market/commodity result.
- **FarmPool:** some partner data is simulated and must remain explicitly labeled.
- **Payments:** no real payment gateway is integrated.
- **Quality:** current grading is heuristic/demo, not a trained production CV model.
- **Database:** SQLite is suitable for zero-config development but not the final scale architecture.
- **Browser testing:** responsive/cross-browser validation requires real browser testing.
- **Multilingual UI:** translation coverage is still being expanded across all high-traffic surfaces.

These limitations are documented because a trustworthy prototype should distinguish what is working from what is still being hardened.

---

## 🎯 SIH 2026 Alignment

CropWise is being developed for:

> **SIH 2026 — PS-26132**  
> **Strengthening Market Linkages and Price Discovery for Farmers**

The project focuses on the core workflow around:

- market intelligence
- price discovery
- price forecasting
- direct buyer discovery
- farmer-to-market linkage

CropWise should be presented as a **working integrated prototype**, not as a claim of nationwide production-scale coverage.

---

## 🗺️ Roadmap

### Next engineering priorities

- [ ] Fix strict live market-record validation
- [ ] Add explicit FarmPool simulated-data labeling
- [ ] Resolve passlib/bcrypt compatibility
- [ ] Expand assistant regression tests
- [ ] Complete high-traffic UI translations
- [ ] Deep-audit marketplace and transaction edge cases
- [ ] Perform responsive/browser validation

### Longer-term

- [ ] Advanced time-series models
- [ ] Learned recommendation/ranking
- [ ] Trained crop-quality vision model
- [ ] Larger live market coverage
- [ ] FPO/bulk-buyer workflows
- [ ] PostgreSQL/cloud-scale deployment
- [ ] Real payment integration
- [ ] Richer multilingual semantic NLU

---

## 📚 Technical Documentation

| Document | Purpose |
|---|---|
| [Architecture](docs/ARCHITECTURE.md) | System layers, data flow and module responsibilities |
| [Data Provenance](docs/DATA_PROVENANCE.md) | LIVE/DEMO/ESTIMATED/UNAVAILABLE rules and market-data behavior |
| [Multilingual](docs/MULTILINGUAL.md) | Language architecture, capability boundaries and assistant behavior |
| [Security](docs/SECURITY.md) | Authentication, RBAC, privacy and deployment considerations |
| [Implementation Status](docs/IMPLEMENTATION_STATUS.md) | Current verified state, known gaps and validation notes |

---

# 🌾 CropWise

### Smart Markets. Better Prices. Stronger Farmers.

> **Price ≠ Best Selling Option**

A decision-support platform designed to make agricultural selling choices more **connected, transparent and explainable**.
